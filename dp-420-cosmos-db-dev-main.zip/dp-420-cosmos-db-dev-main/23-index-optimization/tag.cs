public record Tag(
    string id,
    string name
);